require('dotenv').config();
const app = require('./app');
const { sequelize } = require('./models');

const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    await sequelize.authenticate();
    console.log('✓ Conexión a PostgreSQL establecida.');

    await sequelize.sync({ alter: true });
    console.log('✓ Modelos sincronizados.');

    app.listen(PORT, () => {
      console.log(`✓ MarketSoft API ejecutándose en http://localhost:${PORT}`);
      console.log(`✓ Swagger disponible en http://localhost:${PORT}/api-docs`);
    });
  } catch (error) {
    console.error('✗ No se pudo iniciar el servidor:', error.message);
    process.exit(1);
  }
}

startServer();
