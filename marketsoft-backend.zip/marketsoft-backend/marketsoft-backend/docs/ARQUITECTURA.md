# Arquitectura MVC de MarketSoft

```text
                    CLIENTE
                       |
                       v
                +-------------+
                |    ROUTES   |
                +-------------+
                       |
                       v
                +-------------+
                | CONTROLLERS |
                +-------------+
                       |
                       v
                +-------------+
                |   MODELS    |
                |  Sequelize  |
                +-------------+
                       |
                       v
                +-------------+
                | PostgreSQL  |
                +-------------+
                       |
                       v
                  JSON RESPONSE
```

## Responsabilidades

### Routes

Define las URLs y métodos HTTP.

### Controllers

Contienen la lógica de negocio.

### Models

Definen las entidades, atributos, validaciones y relaciones Sequelize.

### PostgreSQL

Almacena los datos persistentes.

### Swagger

Permite consultar la documentación de la API mediante `/api-docs`.
