## 1. Proveedor
POST `/api/providers`
```json
{
  "name": "Proveedor Uno",
  "phone": "3000000000",
  "email": "proveedor1@example.com",
  "city": "Bogotá"
}
```
## 2. Producto válido
POST `/api/products`
```json
{
  "name": "Leche",
  "description": "Leche entera",
  "price": 5000,
  "stock": 20,
  "providerId": 1
}
```
## 3. Producto inválido
Intentar:
```json
{
  "name": "Producto inválido",
  "price": -10,
  "stock": -5,
  "providerId": 1
}
```
## 4. Usuario
POST `/api/users`
```json
{
  "name": "Carlos Gómez",
  "email": "carlos@example.com",
  "role": "customer"
}
```
## 5. Venta
POST `/api/sales`
```json
{
  "userId": 1,
  "details": [
    {
      "productId": 1,
      "quantity": 2
    }
  ]
}
```
## 6. CRUD
Para cada recurso comprobar:
- GET colección
- GET por ID
- POST
- PUT
- DELETE
Recursos:
- `/api/products`
- `/api/users`
- `/api/providers`
- `/api/sales`
- `/api/sale-details`
