const sequelize = require('../config/database');

const Product = require('./Product');
const User = require('./User');
const Provider = require('./Provider');
const Sale = require('./Sale');
const SaleDetail = require('./SaleDetail');

// Proveedor -> Productos
Provider.hasMany(Product, {
  foreignKey: 'providerId',
  as: 'products',
  onDelete: 'RESTRICT'
});
Product.belongsTo(Provider, {
  foreignKey: 'providerId',
  as: 'provider'
});

// Usuario -> Ventas
User.hasMany(Sale, {
  foreignKey: 'userId',
  as: 'sales',
  onDelete: 'RESTRICT'
});
Sale.belongsTo(User, {
  foreignKey: 'userId',
  as: 'user'
});

// Venta -> Detalles
Sale.hasMany(SaleDetail, {
  foreignKey: 'saleId',
  as: 'details',
  onDelete: 'CASCADE'
});
SaleDetail.belongsTo(Sale, {
  foreignKey: 'saleId',
  as: 'sale'
});

// Producto -> Detalles
Product.hasMany(SaleDetail, {
  foreignKey: 'productId',
  as: 'saleDetails',
  onDelete: 'RESTRICT'
});
SaleDetail.belongsTo(Product, {
  foreignKey: 'productId',
  as: 'product'
});

module.exports = {
  sequelize,
  Product,
  User,
  Provider,
  Sale,
  SaleDetail
};
