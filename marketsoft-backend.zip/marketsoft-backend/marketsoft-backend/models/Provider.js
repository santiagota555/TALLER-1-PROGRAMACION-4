const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Provider = sequelize.define('Provider', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING(120),
    allowNull: false,
    validate: {
      notEmpty: { msg: 'El nombre es obligatorio.' }
    }
  },
  phone: {
    type: DataTypes.STRING(30),
    allowNull: true
  },
  email: {
    type: DataTypes.STRING(160),
    allowNull: true,
    validate: {
      isEmail: { msg: 'El email no tiene un formato válido.' }
    }
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: true
  }
});

module.exports = Provider;
