const { User } = require('../models');

const handleError = (res, error) => {
  console.error(error);
  const duplicate = error.name === 'SequelizeUniqueConstraintError';
  return res.status(400).json({
    success: false,
    message: duplicate ? 'El email ya está registrado.' : error.message,
    errors: error.errors?.map(e => e.message) || []
  });
};

exports.getAll = async (req, res) => {
  try {
    const users = await User.findAll({ order: [['id', 'ASC']] });
    res.json({ success: true, data: users });
  } catch (error) { handleError(res, error); }
};

exports.getById = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'Usuario no encontrado.' });
    res.json({ success: true, data: user });
  } catch (error) { handleError(res, error); }
};

exports.create = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json({ success: true, data: user, message: 'Usuario creado correctamente.' });
  } catch (error) { handleError(res, error); }
};

exports.update = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'Usuario no encontrado.' });
    await user.update(req.body);
    res.json({ success: true, data: user, message: 'Usuario actualizado correctamente.' });
  } catch (error) { handleError(res, error); }
};

exports.remove = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'Usuario no encontrado.' });
    await user.destroy();
    res.json({ success: true, message: 'Usuario eliminado correctamente.' });
  } catch (error) { handleError(res, error); }
};
