const { Sale, User, SaleDetail, Product, sequelize } = require('../models');

const handleError = (res, error) => {
  console.error(error);
  res.status(400).json({
    success: false,
    message: error.message,
    errors: error.errors?.map(e => e.message) || []
  });
};

exports.getAll = async (req, res) => {
  try {
    const sales = await Sale.findAll({
      include: [
        { model: User, as: 'user' },
        {
          model: SaleDetail,
          as: 'details',
          include: [{ model: Product, as: 'product' }]
        }
      ],
      order: [['id', 'ASC']]
    });
    res.json({ success: true, data: sales });
  } catch (error) { handleError(res, error); }
};

exports.getById = async (req, res) => {
  try {
    const sale = await Sale.findByPk(req.params.id, {
      include: [
        { model: User, as: 'user' },
        {
          model: SaleDetail,
          as: 'details',
          include: [{ model: Product, as: 'product' }]
        }
      ]
    });
    if (!sale) return res.status(404).json({ success: false, message: 'Venta no encontrada.' });
    res.json({ success: true, data: sale });
  } catch (error) { handleError(res, error); }
};

exports.create = async (req, res) => {
  const transaction = await sequelize.transaction();

  try {
    const { userId, date, details } = req.body;

    if (!userId) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'userId es obligatorio.' });
    }

    if (!Array.isArray(details) || details.length === 0) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'La venta debe contener al menos un detalle.' });
    }

    const user = await User.findByPk(userId, { transaction });
    if (!user) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'El usuario indicado no existe.' });
    }

    const sale = await Sale.create({
      userId,
      date: date || new Date(),
      total: 0
    }, { transaction });

    let total = 0;

    for (const item of details) {
      const product = await Product.findByPk(item.productId, { transaction, lock: transaction.LOCK.UPDATE });

      if (!product) {
        throw new Error(`El producto ${item.productId} no existe.`);
      }

      const quantity = Number(item.quantity);
      if (!Number.isInteger(quantity) || quantity <= 0) {
        throw new Error(`La cantidad del producto ${item.productId} debe ser un entero mayor a 0.`);
      }

      if (product.stock < quantity) {
        throw new Error(`Stock insuficiente para el producto ${product.name}. Disponible: ${product.stock}.`);
      }

      const price = Number(product.price);
      total += price * quantity;

      await SaleDetail.create({
        saleId: sale.id,
        productId: product.id,
        quantity,
        price
      }, { transaction });

      product.stock -= quantity;
      await product.save({ transaction });
    }

    await sale.update({ total: total.toFixed(2) }, { transaction });
    await transaction.commit();

    const result = await Sale.findByPk(sale.id, {
      include: [
        { model: User, as: 'user' },
        {
          model: SaleDetail,
          as: 'details',
          include: [{ model: Product, as: 'product' }]
        }
      ]
    });

    res.status(201).json({
      success: true,
      data: result,
      message: 'Venta creada y total calculado automáticamente.'
    });
  } catch (error) {
    await transaction.rollback();
    handleError(res, error);
  }
};

exports.update = async (req, res) => {
  try {
    const sale = await Sale.findByPk(req.params.id);
    if (!sale) return res.status(404).json({ success: false, message: 'Venta no encontrada.' });

    // El total no se acepta directamente: se conserva/calcula a partir de sus detalles.
    if (req.body.userId) {
      const user = await User.findByPk(req.body.userId);
      if (!user) return res.status(400).json({ success: false, message: 'El usuario indicado no existe.' });
      sale.userId = req.body.userId;
    }
    if (req.body.date) sale.date = req.body.date;
    await sale.save();

    res.json({ success: true, data: sale, message: 'Venta actualizada correctamente.' });
  } catch (error) { handleError(res, error); }
};

exports.remove = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const sale = await Sale.findByPk(req.params.id, { transaction });
    if (!sale) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Venta no encontrada.' });
    }

    const details = await SaleDetail.findAll({ where: { saleId: sale.id }, transaction });

    for (const detail of details) {
      const product = await Product.findByPk(detail.productId, { transaction, lock: transaction.LOCK.UPDATE });
      if (product) {
        product.stock += detail.quantity;
        await product.save({ transaction });
      }
    }

    await sale.destroy({ transaction });
    await transaction.commit();

    res.json({ success: true, message: 'Venta eliminada y stock restaurado correctamente.' });
  } catch (error) {
    await transaction.rollback();
    handleError(res, error);
  }
};
