const { SaleDetail, Sale, Product, sequelize } = require('../models');

const handleError = (res, error) => {
  console.error(error);
  res.status(400).json({
    success: false,
    message: error.message,
    errors: error.errors?.map(e => e.message) || []
  });
};

async function recalculateSaleTotal(saleId, transaction) {
  const details = await SaleDetail.findAll({ where: { saleId }, transaction });
  const total = details.reduce((sum, detail) => sum + Number(detail.price) * detail.quantity, 0);
  await Sale.update({ total: total.toFixed(2) }, { where: { id: saleId }, transaction });
}

exports.getAll = async (req, res) => {
  try {
    const details = await SaleDetail.findAll({
      include: [
        { model: Sale, as: 'sale' },
        { model: Product, as: 'product' }
      ],
      order: [['id', 'ASC']]
    });
    res.json({ success: true, data: details });
  } catch (error) { handleError(res, error); }
};

exports.getById = async (req, res) => {
  try {
    const detail = await SaleDetail.findByPk(req.params.id, {
      include: [
        { model: Sale, as: 'sale' },
        { model: Product, as: 'product' }
      ]
    });
    if (!detail) return res.status(404).json({ success: false, message: 'Detalle de venta no encontrado.' });
    res.json({ success: true, data: detail });
  } catch (error) { handleError(res, error); }
};

exports.create = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const { saleId, productId, quantity } = req.body;

    const sale = await Sale.findByPk(saleId, { transaction });
    if (!sale) throw new Error('La venta indicada no existe.');

    const product = await Product.findByPk(productId, { transaction, lock: transaction.LOCK.UPDATE });
    if (!product) throw new Error('El producto indicado no existe.');

    const qty = Number(quantity);
    if (!Number.isInteger(qty) || qty <= 0) throw new Error('La cantidad debe ser un entero mayor a 0.');
    if (product.stock < qty) throw new Error(`Stock insuficiente para ${product.name}.`);

    const detail = await SaleDetail.create({
      saleId,
      productId,
      quantity: qty,
      price: product.price
    }, { transaction });

    product.stock -= qty;
    await product.save({ transaction });
    await recalculateSaleTotal(saleId, transaction);

    await transaction.commit();

    res.status(201).json({ success: true, data: detail, message: 'Detalle creado y total de venta actualizado.' });
  } catch (error) {
    await transaction.rollback();
    handleError(res, error);
  }
};

exports.update = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const detail = await SaleDetail.findByPk(req.params.id, { transaction });
    if (!detail) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Detalle de venta no encontrado.' });
    }

    const newQuantity = req.body.quantity !== undefined ? Number(req.body.quantity) : detail.quantity;
    if (!Number.isInteger(newQuantity) || newQuantity <= 0) throw new Error('La cantidad debe ser un entero mayor a 0.');

    const product = await Product.findByPk(detail.productId, { transaction, lock: transaction.LOCK.UPDATE });
    if (!product) throw new Error('El producto asociado no existe.');

    const difference = newQuantity - detail.quantity;

    if (difference > 0 && product.stock < difference) {
      throw new Error(`Stock insuficiente. Disponible: ${product.stock}.`);
    }

    product.stock -= difference;
    await product.save({ transaction });

    detail.quantity = newQuantity;
    await detail.save({ transaction });

    await recalculateSaleTotal(detail.saleId, transaction);
    await transaction.commit();

    res.json({ success: true, data: detail, message: 'Detalle actualizado y total recalculado.' });
  } catch (error) {
    await transaction.rollback();
    handleError(res, error);
  }
};

exports.remove = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const detail = await SaleDetail.findByPk(req.params.id, { transaction });
    if (!detail) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'Detalle de venta no encontrado.' });
    }

    const product = await Product.findByPk(detail.productId, { transaction, lock: transaction.LOCK.UPDATE });
    if (product) {
      product.stock += detail.quantity;
      await product.save({ transaction });
    }

    const saleId = detail.saleId;
    await detail.destroy({ transaction });
    await recalculateSaleTotal(saleId, transaction);

    await transaction.commit();

    res.json({ success: true, message: 'Detalle eliminado, stock restaurado y total recalculado.' });
  } catch (error) {
    await transaction.rollback();
    handleError(res, error);
  }
};
