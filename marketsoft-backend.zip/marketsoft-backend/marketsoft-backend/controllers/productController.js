const { Product, Provider } = require('../models');

const handleError = (res, error) => {
  console.error(error);
  return res.status(400).json({
    success: false,
    message: error.message,
    errors: error.errors?.map(e => e.message) || []
  });
};

exports.getAll = async (req, res) => {
  try {
    const products = await Product.findAll({
      include: [{ model: Provider, as: 'provider' }],
      order: [['id', 'ASC']]
    });
    res.json({ success: true, data: products });
  } catch (error) {
    handleError(res, error);
  }
};

exports.getById = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id, {
      include: [{ model: Provider, as: 'provider' }]
    });
    if (!product) return res.status(404).json({ success: false, message: 'Producto no encontrado.' });
    res.json({ success: true, data: product });
  } catch (error) {
    handleError(res, error);
  }
};

exports.create = async (req, res) => {
  try {
    const { providerId } = req.body;
    const provider = await Provider.findByPk(providerId);
    if (!provider) return res.status(400).json({ success: false, message: 'El proveedor indicado no existe.' });

    const product = await Product.create(req.body);
    res.status(201).json({ success: true, data: product, message: 'Producto creado correctamente.' });
  } catch (error) {
    handleError(res, error);
  }
};

exports.update = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Producto no encontrado.' });

    if (req.body.providerId) {
      const provider = await Provider.findByPk(req.body.providerId);
      if (!provider) return res.status(400).json({ success: false, message: 'El proveedor indicado no existe.' });
    }

    await product.update(req.body);
    res.json({ success: true, data: product, message: 'Producto actualizado correctamente.' });
  } catch (error) {
    handleError(res, error);
  }
};

exports.remove = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Producto no encontrado.' });

    await product.destroy();
    res.json({ success: true, message: 'Producto eliminado correctamente.' });
  } catch (error) {
    handleError(res, error);
  }
};
