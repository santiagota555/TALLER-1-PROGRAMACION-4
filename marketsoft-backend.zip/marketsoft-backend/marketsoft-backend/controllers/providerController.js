const { Provider } = require('../models');

const handleError = (res, error) => {
  console.error(error);
  res.status(400).json({
    success: false,
    message: error.message,
    errors: error.errors?.map(e => e.message) || []
  });
};

exports.getAll = async (req, res) => {
  try {
    const providers = await Provider.findAll({ order: [['id', 'ASC']] });
    res.json({ success: true, data: providers });
  } catch (error) { handleError(res, error); }
};

exports.getById = async (req, res) => {
  try {
    const provider = await Provider.findByPk(req.params.id);
    if (!provider) return res.status(404).json({ success: false, message: 'Proveedor no encontrado.' });
    res.json({ success: true, data: provider });
  } catch (error) { handleError(res, error); }
};

exports.create = async (req, res) => {
  try {
    const provider = await Provider.create(req.body);
    res.status(201).json({ success: true, data: provider, message: 'Proveedor creado correctamente.' });
  } catch (error) { handleError(res, error); }
};

exports.update = async (req, res) => {
  try {
    const provider = await Provider.findByPk(req.params.id);
    if (!provider) return res.status(404).json({ success: false, message: 'Proveedor no encontrado.' });
    await provider.update(req.body);
    res.json({ success: true, data: provider, message: 'Proveedor actualizado correctamente.' });
  } catch (error) { handleError(res, error); }
};

exports.remove = async (req, res) => {
  try {
    const provider = await Provider.findByPk(req.params.id);
    if (!provider) return res.status(404).json({ success: false, message: 'Proveedor no encontrado.' });
    await provider.destroy();
    res.json({ success: true, message: 'Proveedor eliminado correctamente.' });
  } catch (error) { handleError(res, error); }
};
