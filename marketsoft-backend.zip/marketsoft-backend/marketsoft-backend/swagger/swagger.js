const swaggerJSDoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'MarketSoft API',
      version: '1.0.0',
      description: 'API REST para la gestión básica de un supermercado.'
    },
    servers: [
      {
        url: 'http://localhost:3000',
        description: 'Servidor local'
      }
    ],
    components: {
      schemas: {
        Provider: {
          type: 'object',
          required: ['name'],
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Distribuciones ABC' },
            phone: { type: 'string', example: '3001234567' },
            email: { type: 'string', format: 'email', example: 'ventas@abc.com' },
            city: { type: 'string', example: 'Bogotá' }
          }
        },
        Product: {
          type: 'object',
          required: ['name', 'price', 'stock', 'providerId'],
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Arroz 1 kg' },
            description: { type: 'string', example: 'Arroz blanco' },
            price: { type: 'number', format: 'float', minimum: 0.01, example: 4500 },
            stock: { type: 'integer', minimum: 0, example: 50 },
            providerId: { type: 'integer', example: 1 }
          }
        },
        User: {
          type: 'object',
          required: ['name', 'email'],
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Ana Pérez' },
            email: { type: 'string', format: 'email', example: 'ana@example.com' },
            role: { type: 'string', example: 'customer' }
          }
        },
        SaleDetailInput: {
          type: 'object',
          required: ['productId', 'quantity'],
          properties: {
            productId: { type: 'integer', example: 1 },
            quantity: { type: 'integer', minimum: 1, example: 2 }
          }
        },
        SaleInput: {
          type: 'object',
          required: ['userId', 'details'],
          properties: {
            userId: { type: 'integer', example: 1 },
            date: { type: 'string', format: 'date-time' },
            details: {
              type: 'array',
              items: { $ref: '#/components/schemas/SaleDetailInput' }
            }
          }
        }
      }
    },
    paths: {
      '/api/providers': {
        get: { summary: 'Listar proveedores', responses: { 200: { description: 'OK' } } },
        post: { 
          summary: 'Crear proveedor',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  $ref: '#/components/schemas/Provider'
                }
              }
            }
          },
          responses: { 201: { description: 'Creado' } } 
        }
      },
      '/api/products': {
        get: { summary: 'Listar productos', responses: { 200: { description: 'OK' } } },
        post: {
          summary: 'Crear producto',
          requestBody: {
            required: true,
            content: { 'application/json': { schema: { $ref: '#/components/schemas/Product' } } }
          },
          responses: { 201: { description: 'Creado' } }
        }
      },
      '/api/users': {
        get: { summary: 'Listar usuarios', responses: { 200: { description: 'OK' } } },
        post: { 
          summary: 'Crear usuario',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  $ref: '#/components/schemas/User'
                }
              }
            }
          },
          responses: { 201: { description: 'Creado' } } 
        }
      },
      '/api/sales': {
        get: { summary: 'Listar ventas', responses: { 200: { description: 'OK' } } },
        post: {
          summary: 'Crear venta y calcular total automáticamente',
          requestBody: {
            required: true,
            content: { 'application/json': { schema: { $ref: '#/components/schemas/SaleInput' } } }
          },
          responses: { 201: { description: 'Venta creada' } }
        }
      },
      '/api/sale-details': {
        get: { summary: 'Listar detalles de venta', responses: { 200: { description: 'OK' } } },
        post: { summary: 'Crear detalle de venta', responses: { 201: { description: 'Creado' } } }
      }
    }
  },
  apis: []
};

module.exports = swaggerJSDoc(options);